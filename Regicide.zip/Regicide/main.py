import pygame
import random
import sys

WHITE = pygame.Color(255,255,255)
BLACK = pygame.Color(0,0,0)
RED = pygame.Color(255,0,0)
LIGHTIVORY = pygame.Color(255,255,240)
DARKIVORY = pygame.Color(228,228,224)
GRAY = pygame.Color(224,224,224,10)

SCREENWIDTH = 1600
SCREENHEIGHT = 900

class Button():
    '''
    按钮封装
    '''
    color = LIGHTIVORY
    callback = None
    def __init__(self,x,y,width,height,text:str) -> None:
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text_size = 30
        self.text_surface = MainGame.get_text_surface(MainGame,text,BLACK,self.text_size)
    def display_button(self) -> None:
        mx,my = pygame.mouse.get_pos()
        pygame.draw.rect(MainGame.window,self.color,(self.x,self.y,self.width,self.height),0,8)
        MainGame.window.blit(self.text_surface,(self.x+self.width/2-self.text_surface.get_width()/2,self.y+self.height/2-self.text_surface.get_height()/2))
        if is_over_rectangle(mx,my,self.x,self.y,self.width,self.height):
            self.color =  DARKIVORY
            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.callback()
        else:
            self.color = LIGHTIVORY
    def callback(self) -> None:
        pass

class GiveUpButton(Button):
    def __init__(self, x, y, width, height, text: str) -> None:
        super().__init__(x, y, width, height, text)
    def display_button(self) -> None:
        return super().display_button()
    def callback(self) -> None:
        MainGame.game_over = True
        MainGame.game_lose = True

class StartButton(Button):
    def __init__(self, x, y, width, height, text: str) -> None:
        super().__init__(x, y, width, height, text)
    def display_button(self) -> None:
        super().display_button()
    def callback(self) -> None:
        #标记开始
        MainGame.is_start = True
        StaticTime.start_time = pygame.time.get_ticks()
        MainGame.display_list.display_allowance['开始游戏'] = True
        #boss堆摸牌
        MainGame.table.draw_boss()
        #手牌堆摸牌
        MainGame.table.draw_cards(8)

class UseButton(Button):
    def __init__(self, x, y, width, height, text: str) -> None:
        super().__init__(x, y, width, height, text)
    def display_button(self) -> None:
        super().display_button()
    def callback(self) -> None:
        MainGame.table.use_card()

class JokerButton(Button):
    def __init__(self, x, y, width, height, text: str) -> None:
        super().__init__(x, y, width, height, text)
        self.text_size = 20
        self.text_surface = MainGame.get_text_surface(MainGame,text,BLACK,self.text_size)
    def display_button(self) -> None:
        mx,my = pygame.mouse.get_pos()
        pygame.draw.rect(MainGame.window,self.color,(self.x,self.y,self.width,self.height),0,4)
        MainGame.window.blit(self.text_surface,(self.x+self.width/2-self.text_surface.get_width()/2,self.y+self.height/2-self.text_surface.get_height()/2))
        if is_over_rectangle(mx,my,self.x,self.y,self.width,self.height):
            self.color =  DARKIVORY
            event_list = pygame.event.get()
            for event in event_list:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.callback()
        else:
            self.color = LIGHTIVORY
    def callback(self) -> None:
        if MainGame.joker.count > 0:
            handcards_copy = []
            for card in MainGame.table.handcards:
                handcards_copy.append(card)
            for card in handcards_copy:
                MainGame.cards[card].unlist()
            MainGame.table.draw_cards(8)
            MainGame.joker.count -= 1
        else:
            StaticTime.start_time = pygame.time.get_ticks()
            MainGame.display_list.display_allowance['Joker已耗尽'] = True

class Card:
    is_display = False
    is_move = True
    def __init__(self,type: str,number,row,col) -> None:
        #设置名字
        self.name = type+str(number)
        #设置花色: 黑桃（spade）红桃（heart）梅花（club）方块（diamond）
        self.type = type
        #设置点数
        self.number = number
        #设置图片
        self.width = 140
        self.height = 200
        self.images = pygame.image.load('./lib/Images/httpcloud3steamusercontentcomugc1751317268507165668E511FC096CB4B2172E19221DDC4150A5F6E483E9.png')
        w,h = self.images.get_size()
        self.image = self.images.subsurface(pygame.Rect(col/9*w,row/6*h,w/9,h/6))
        self.image = pygame.transform.scale(self.image,(self.width,self.height))
        #设置位置
        self.pos = [550,600]

    def display_card(self) -> None:
        if self.is_display:
            MainGame.window.blit(self.image,self.pos)

    def move(self,mx,my) -> None:
        if self.is_move:
            self.pos = (mx-StaticTime.mouse_dpos[0],my-StaticTime.mouse_dpos[1])

    def unlist(self) -> None:
        self.is_display = False
        MainGame.throwdump.card_list.append(self.name) #放进弃牌堆
        MainGame.throwdump.count += 1
        MainGame.table.handcards.remove(self.name)     #从手牌堆去除
        MainGame.table.count -= 1

class SCard(Card):
    def __init__(self, type: str, number, row, col) -> None:
        Card.__init__(self,type, number, row, col)
        if number == 10: self.name = type + "J"
        if number == 15: self.name = type + "Q"
        if number == 20: self.name = type + "K"
        self.maxHP = number*2
        self.HP = number*2
        self.pos = [10,10]
        self.is_move = False

    def display_card(self) -> None:
        Card.display_card(self)

    def move(self, mx, my) -> None:
        Card.move(self,mx,my)

    def injury(self,num) -> None:
        if self.HP - num == 0:  #收服
            self.enlist()
        elif self.HP - num > 0: #受伤
            self.HP -= num
        else:                   #死亡
            self.HP = 0
            self.unlist()

    def enlist(self) -> None:
        '''
        荣誉击败(收服)
        '''
        StaticTime.start_time = pygame.time.get_ticks()
        MainGame.display_list.display_allowance['击败了Boss'] = True
        MainGame.drawdump.card_list.insert(0,self.name) #放置抽牌堆顶
        MainGame.drawdump.count += 1
        self.is_move = True
        MainGame.cards[self.name].is_move = True
        MainGame.table.draw_boss()  #抽取下一张boss
        MainGame.table.stage = 0
        
    def unlist(self) -> None:
        if self.is_move == False:
            StaticTime.start_time = pygame.time.get_ticks()
            MainGame.display_list.display_allowance['击败了Boss'] = True
            MainGame.throwdump.card_list.append(self.name) #放进弃牌堆
            MainGame.throwdump.count += 1
            self.is_move = True
            MainGame.cards[self.name].is_move = True
            MainGame.table.draw_boss()  #抽取下一张boss
            MainGame.table.stage = 0
        else:
            Card.unlist(self)

class JCard(Card):
    count = 2
    def __init__(self, type: str, number, row, col) -> None:
        super().__init__(type, number, row, col)
        self.is_move = False
        self.is_display = True
        self.pos = [1025,10]
        self.width = 105
        self.height = 150
        self.image = pygame.transform.scale(self.image,(self.width,self.height))

    def display_card(self) -> None:
        Card.display_card(self)
        MainGame.window.blit(MainGame.get_text_surface(MainGame,'x{}'.format(self.count),WHITE,30),(1150,10))

class Table:
    '''
    游戏桌
    '''
    #手牌
    handcards = []
    count = 0
    cardpos = [[50-25,680],[200-25,680],[350-25,680],[500-25,680],[650-25,680],[800-25,680],[950-25,680],[1100-25,680]]
    selectcards = []
    selectcards_show = ''
    stage = 0
    stage_sign = ["使用卡牌击败Boss","弃置卡牌进行防御"]
    boss = 'None'
    move_boss = False
    defend = 0
    move_drawdump = False
    road_drawdump = [SCREENWIDTH-340,460]
    image = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc1816637110751246597B04AC5C9EFDBC2088E12BBDC307517DD9BADA06A4.png'),(140,50))
    #出牌区
    area = (50,255,1140,400) #width=1140 height=400
    area_image = pygame.image.load('lib\Images/area.png')

    def __init__(self) -> None:
        pass

    def update(self) -> None:
        '''
        更新卡牌展示状态、位置
        '''
        for i in range(0,len(self.handcards)):
            #print(self.handcards)
            MainGame.cards[self.handcards[i]].is_display = True
            MainGame.cards[self.handcards[i]].pos = self.cardpos[i]
            self.road_drawdump = [1260,460]

    def display_table(self) -> None:
        #展示出牌区
        MainGame.window.blit(self.area_image,self.area)
        #检测所选卡牌
        self.detect()
        #展示所选卡牌
        if len(self.selectcards) > 0:
            MainGame.window.blit(MainGame.get_text_surface(MainGame,"{}".format(self.selectcards_show),WHITE,20),(60,270))
        #展示Boss
        if self.boss != 'None':
            MainGame.window.blit(self.image,(550,0))
            #HP条
            MainGame.window.blit(MainGame.get_text_surface(MainGame,'HP',BLACK,30),(710,75))
            pygame.draw.rect(MainGame.window,WHITE,(750,75,178,30),5)
            pygame.draw.rect(MainGame.window,RED,(755,80,168*MainGame.cards[self.boss].HP/MainGame.cards[self.boss].maxHP,20),0)
            MainGame.window.blit(MainGame.get_text_surface(MainGame,'{}'.format(MainGame.cards[self.boss].HP),BLACK,20),(755+72,80))
            #攻击条
            MainGame.window.blit(MainGame.get_text_surface(MainGame,'攻击',BLACK,25),(700,117.5))
            pygame.draw.rect(MainGame.window,WHITE,(750,115,178,30),5)
            pygame.draw.rect(MainGame.window,RED,(755,120,168*((MainGame.cards[self.boss].number-self.defend) if (MainGame.cards[self.boss].number-self.defend)>0 else 0)/MainGame.cards[self.boss].number,20),0)
            MainGame.window.blit(MainGame.get_text_surface(MainGame,'{}'.format((MainGame.cards[self.boss].number-self.defend) if (MainGame.cards[self.boss].number-self.defend)>0 else 0),BLACK,20),(755+72,120))
            #stage提示词
            MainGame.window.blit(MainGame.get_text_surface(MainGame,self.stage_sign[self.stage],WHITE,30),(925,275))
        if self.move_boss:
            if MainGame.timer % 1 == 0: #550,50
                if MainGame.cards[self.boss].pos[0] != 550:
                    MainGame.cards[self.boss].pos[0] += 6.75 #(550-10)/80
                if MainGame.cards[self.boss].pos[1] != 50:
                    MainGame.cards[self.boss].pos[1] += 0.5 #(50-10)/80
                if MainGame.cards[self.boss].pos[0] >= 550 and MainGame.cards[self.boss].pos[1] >= 50:
                    self.move_boss = False
        if self.move_drawdump:
            if MainGame.timer % 1 == 0: #550,700
                if self.road_drawdump[0] != 550:
                    self.road_drawdump[0] += -7.1 #(550-1260)/100
                if self.road_drawdump[1] != 680:
                    self.road_drawdump[1] += 2.2 #(680-460)/100
                if self.road_drawdump[0] <= 550 and self.road_drawdump[1] >= 680:
                    self.move_drawdump = False

    def draw_boss(self) -> None:
        '''
        从boss堆摸牌
        '''
        if self.boss != 'None':
            MainGame.cards[self.boss].is_display = False
        if len(MainGame.bossdump.card_list) == 0:
            MainGame.game_over = True
            MainGame.game_win = True
        else:
            self.boss = MainGame.bossdump.card_list[0]
            del MainGame.bossdump.card_list[0]
            MainGame.bossdump.count -= 1
            #动画许可
            MainGame.cards[self.boss].is_display = True
            self.move_boss = True
            #重新回到出牌阶段
            self.stage = 0
            self.defend = 0

    def draw_cards(self,num) -> None:
        '''
        从抽牌堆摸牌
        '''
        StaticTime.start_time = pygame.time.get_ticks()
        while num > 0:
            if self.count >= 8:
                MainGame.display_list.display_allowance['手牌已满'] = True
                break
            elif MainGame.drawdump.count == 0:
                MainGame.display_list.display_allowance['抽牌堆已空'] = True
                break
            else:
                MainGame.display_list.display_allowance["抽牌"] = True
                self.move_drawdump = True
                self.handcards.append((MainGame.drawdump.card_list[0]))
                self.count += 1
                del MainGame.drawdump.card_list[0]
                MainGame.drawdump.count -= 1
                num -= 1
        #播放音效
        MainGame.sound_drawcards.play_sound()

    def detect(self) -> None:
        '''
        检测出牌区的卡牌
        '''
        for card in self.handcards:
            if (card not in self.selectcards) and is_over_rectangle(MainGame.cards[card].pos[0]+MainGame.cards[card].width/2,MainGame.cards[card].pos[1]+MainGame.cards[card].height/2,self.area[0],self.area[1],self.area[2],self.area[3]):
                self.selectcards.append(card)
            if (card in self.selectcards) and (not is_over_rectangle(MainGame.cards[card].pos[0]+MainGame.cards[card].width/2,MainGame.cards[card].pos[1]+MainGame.cards[card].height/2,self.area[0],self.area[1],self.area[2],self.area[3])):
                self.selectcards.remove(card)
        self.selectcards_show = ''
        for card in self.selectcards:
            if 'spade' in card:
                if card[-1] != '0':
                    if card[-1] == '1':
                        self.selectcards_show += '黑桃' + 'A' + ' '
                    else:
                        self.selectcards_show += '黑桃' + card[-1] + ' '
                else:
                    self.selectcards_show += '黑桃' + card[-2:] + ' '
            if 'heart' in card:
                if card[-1] != '0':
                    if card[-1] == '1':
                        self.selectcards_show += '红桃' + 'A' + ' '
                    else:
                        self.selectcards_show += '红桃' + card[-1] + ' '
                else:
                    self.selectcards_show += '红桃' + card[-2:] + ' '
            if 'diamond' in card:
                if card[-1] != '0':
                    if card[-1] == '1':
                        self.selectcards_show += '方块' + 'A' + ' '
                    else:
                        self.selectcards_show += '方块' + card[-1] + ' '
                else:
                    self.selectcards_show += '方块' + card[-2:] + ' '
            if 'club' in card:
                if card[-1] != '0':
                    if card[-1] == '1':
                        self.selectcards_show += '梅花' + 'A' + ' '
                    else:
                        self.selectcards_show += '梅花' + card[-1] + ' '
                else:
                    self.selectcards_show += '梅花' + card[-2:] + ' '
    
    def use_card(self) -> None:
        '''
        使用选中的卡牌
        '''
        if self.stage == 0: 
            '''
            出牌阶段
            '''
            #进入弃牌阶段
            self.stage = 1
            #判断出牌是否合法
            is_legal = True
            injury_num = 0
            ratio = 1
            if len(self.selectcards) == 0: #跳过出牌
                pass
            elif len(self.selectcards) == 1:  #全部合法
                card = self.selectcards[0]
                card_type = MainGame.cards[self.selectcards[0]].type
                injury_num += MainGame.cards[card].number
                #丢弃卡牌1
                MainGame.cards[card].unlist()
                if card_type == MainGame.cards[self.boss].type:
                    pass
                else:
                    if card_type == 'diamond':   #方块-抽卡
                        self.draw_cards(injury_num)
                    if card_type == 'spade':     #黑桃-防御
                        self.defend += injury_num
                    if card_type == 'heart':     #红桃-从弃牌堆恢复至抽牌堆底
                        MainGame.throwdump.deliver_to(MainGame.drawdump,injury_num)
                    if card_type == 'club':      #梅花-双倍伤害
                        injury_num = 2*injury_num
                #攻击boss
                MainGame.cards[self.boss].injury(injury_num*ratio)
                #丢弃卡牌2
                self.selectcards = []
                #出牌音效
                MainGame.sound_usecards.play_sound()

            elif len(self.selectcards) == 2:    #1:存在宠物牌 2:两张2、3、4、5
                have_pet = False 
                for card in self.selectcards:
                    if card[-1] == '1':
                        have_pet = True
                    if MainGame.cards[card].number > 5:
                        is_legal = False
                if self.selectcards[0][-1] != self.selectcards[1][-1]:
                    is_legal = False
                if have_pet:
                    is_legal = True
                if is_legal:
                    #弃牌1
                    for card in self.selectcards:
                        MainGame.cards[card].unlist()
                    for card in self.selectcards:
                        injury_num += MainGame.cards[card].number
                    for card in self.selectcards:
                        if 'diamond' in card and 'diamond' not in self.boss:
                            self.draw_cards(injury_num)
                        if 'spade' in card and 'spade' not in self.boss:
                            self.defend += injury_num
                        if 'heart' in card and 'heart' not in self.boss:
                            MainGame.throwdump.deliver_to(MainGame.drawdump,injury_num)
                        if 'club' in card and 'club' not in self.boss:
                            ratio = 2
                    MainGame.cards[self.boss].injury(injury_num*ratio)
                    #弃牌2
                    self.selectcards = []
                    #出牌音效
                    MainGame.sound_usecards.play_sound()

            elif len(self.selectcards) == 3:    #三张1、2、3
                flag = self.selectcards[0][-1]
                for card in self.selectcards:
                    if card[-1] != flag:
                        is_legal = False
                        break
                    if MainGame.cards[card].number > 3:
                        is_legal = False
                        break
                if is_legal:
                    injury_num = 3*int(flag)
                    #弃牌1
                    for card in self.selectcards:
                        MainGame.cards[card].unlist()
                    for card in self.selectcards:
                            if 'diamond' in card and 'diamond' not in self.boss:
                                self.draw_cards(injury_num)
                            if 'spade' in card and 'spade' not in self.boss:
                                self.defend += injury_num
                            if 'heart' in card and 'heart' not in self.boss:
                                MainGame.throwdump.deliver_to(MainGame.drawdump,injury_num)
                            if 'club' in card and 'club' not in self.boss:
                                ratio = 2
                    MainGame.cards[self.boss].injury(injury_num*ratio)
                    #弃牌2
                    self.selectcards = []
                    #出牌音效
                    MainGame.sound_usecards.play_sound()

            elif len(self.selectcards) == 4:    #四张1、2
                flag = self.selectcards[0][-1]
                for card in self.selectcards:
                    if card[-1] != flag:
                        is_legal = False
                        break
                    if MainGame.cards[card].number > 2:
                        is_legal = False
                        break
                if is_legal:
                    #弃牌
                    for card in self.selectcards:
                        MainGame.cards[card].unlist()
                    self.selectcards = []
                    injury_num = int(flag)*4
                    #卡牌效果
                    for card in self.selectcards:
                        if 'diamond' in card and 'diamond' not in self.boss:
                            self.draw_cards(injury_num)
                        if 'spade' in card and 'spade' not in self.boss:
                            self.defend += injury_num
                        if 'heart' in card and 'heart' not in self.boss:
                            MainGame.throwdump.deliver_to(MainGame.drawdump,injury_num)
                        if 'club' in card and 'club' not in self.boss:
                            ratio = 2
                    MainGame.cards[self.boss].injury(injury_num*ratio)
                    #出牌音效
                    MainGame.sound_usecards.play_sound()

            else:   #其余均非法
                is_legal = False
            #如果出牌非法
            if not is_legal:
                self.stage = 0
                StaticTime.start_time = pygame.time.get_ticks()
                MainGame.display_list.display_allowance['出牌非法'] = True

        elif self.stage == 1:
            '''
            弃牌阶段
            '''
            #返回出牌阶段
            self.stage = 0

            injury_num = (MainGame.cards[self.boss].number-self.defend) if (MainGame.cards[self.boss].number-self.defend)>0 else 0
            defend_num = 0
            for card in self.selectcards:
                defend_num += MainGame.cards[card].number
            if defend_num >= injury_num:
                #丢弃卡牌
                for card in self.selectcards:
                    MainGame.cards[card].unlist()
                self.selectcards = []
            else:
                #游戏失败
                StaticTime.start_time = pygame.time.get_ticks()
                MainGame.game_over = True
                MainGame.game_lose = True

class Dump:
    pass
class Dump:
    '''
    卡牌堆
    '''
    card_list = []
    image = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc175131726850716606390CDE6E1CACEF6ED189D8D24D8EBE06BF1A42C5A.png'),(145,200))
    def __init__(self,name:str,x,y,count) -> None:
        self.name = name
        self.x = x
        self.y = y
        self.count = count
        if name == '抽牌堆':
            self.card_list = ['club1','club2','club3','club4','club5','club6','club7','club8','club9','club10','diamond1','diamond2','diamond3','diamond4','diamond5','diamond6','diamond7','diamond8','diamond9','diamond10','heart1','heart2','heart3','heart4','heart5','heart6','heart7','heart8','heart9','heart10','spade1','spade2','spade3','spade4','spade5','spade6','spade7','spade8','spade9','spade10']
            random.shuffle(self.card_list)
        elif name == '弃牌堆':
            self.card_list = []
        else:
            self.card_list_J = ['clubJ','heartJ','spadeJ','diamondJ']
            random.shuffle(self.card_list_J)
            self.card_list_Q = ['clubQ','heartQ','spadeQ','diamondQ']
            random.shuffle(self.card_list_Q)
            self.card_list_K = ['clubK','heartK','spadeK','diamondK']
            random.shuffle(self.card_list_K)
            self.card_list = self.card_list_J+self.card_list_Q+self.card_list_K
    def display_dump(self) -> None:
        MainGame.window.blit(self.image,(self.x,self.y))
        if self.name == 'Boss堆':
            MainGame.window.blit(MainGame.get_text_surface(MainGame,"{} x{}".format(self.name,self.count),WHITE,30),(self.x+155,self.y))
        else:
            MainGame.window.blit(MainGame.get_text_surface(MainGame,"{} x{}".format(self.name,self.count),BLACK,30),(self.x+155,self.y))
    def deliver_to(self,dest: Dump,times: int) -> None:
        for i in range(0,times):
            if len(self.card_list) == 0:
                break
            else:
                random.shuffle(self.card_list)
                dest.card_list.append(self.card_list[0])
                dest.count += 1
                del self.card_list[0]
                self.count -= 1

class Music:
    '''
    音乐
    '''
    def __init__(self,filename: str) -> None:
        #创建音乐文件
        self.music = pygame.mixer.music.load(filename)
    def play_music(self) -> None:
        '''
        播放音乐
        '''
        pygame.mixer.music.play(-1)

class Sound:
    '''
    音效
    '''
    def __init__(self,filename: str) -> None:
        #创建音效文件
        self.sound = pygame.mixer.Sound(filename)
    def play_sound(self) -> None:
        '''
        播放音效
        '''
        self.sound.play()

########################################################################################
class MainGame:
    '''
    游戏主窗口
    '''

    #游戏主窗口对象
    window = None
    game_over = False
    game_win = False
    game_lose = False
    is_start = False
    is_myturn = True
    is_drag = False
    select_card = "club1"
    table = Table()
    timer = 0

    #卡牌初始化
    cards = {'club1':Card("club",1,0,0), 'club2':Card("club",2,0,1), 'club3':Card("club",3,0,2), 'club4':Card("club",4,0,3), 'club5':Card("club",5,0,4), 'club6':Card("club",6,0,5), 'club7':Card("club",7,0,6), 'club8':Card("club",8,0,7), 'club9':Card("club",9,0,8), 'club10':Card("club",10,1,0), 'clubJ':SCard("club",10,1,1), 'clubQ':SCard("club",15,1,2), 'clubK':SCard("club",20,1,3),
             'diamond1':Card('diamond',1,1,4), 'diamond2':Card('diamond',2,1,5), 'diamond3':Card('diamond',3,1,6), 'diamond3':Card('diamond',3,1,6), 'diamond3':Card('diamond',3,1,6), 'diamond4':Card('diamond',4,1,7), 'diamond5':Card('diamond',5,1,8), 'diamond6':Card('diamond',6,2,0), 'diamond7':Card('diamond',7,2,1), 'diamond8':Card('diamond',8,2,2), 'diamond9':Card('diamond',9,2,3), 'diamond10':Card('diamond',10,2,4), 'diamondJ':SCard('diamond',10,2,5), 'diamondQ':SCard('diamond',15,2,6), 'diamondK':SCard('diamond',20,2,7),
             'heart1':Card('heart',1,2,8), 'heart2':Card('heart',2,3,0), 'heart3':Card('heart',3,3,1), 'heart4':Card('heart',4,3,2), 'heart5':Card('heart',5,3,3), 'heart6':Card('heart',6,3,4), 'heart7':Card('heart',7,3,5), 'heart8':Card('heart',8,3,6), 'heart9':Card('heart',9,3,7), 'heart10':Card('heart',10,3,8), 'heartJ':SCard('heart',10,4,0), 'heartQ':SCard('heart',15,4,1), 'heartK':SCard('heart',20,4,2),
             'spade1':Card('spade',1,4,3), 'spade2':Card('spade',2,4,4), 'spade3':Card('spade',3,4,5), 'spade4':Card('spade',4,4,6), 'spade5':Card('spade',5,4,7), 'spade6':Card('spade',6,4,8), 'spade7':Card('spade',7,5,0), 'spade8':Card('spade',8,5,1), 'spade9':Card('spade',9,5,2), 'spade10':Card('spade',10,5,3), 'spadeJ':SCard('spade',10,5,4), 'spadeQ':SCard('spade',15,5,5), 'spadeK':SCard('spade',20,5,6)}
    joker = JCard('joker',0,5,7)

    def __init__(self) -> None:
        pass

    def start_game(self) -> None:
        '''
        开始游戏
        '''

        #初始化游戏窗口
        pygame.init()
        MainGame.window = pygame.display.set_mode((SCREENWIDTH,SCREENHEIGHT))
        pygame.display.set_caption("弑君者REGICIDE")
        clock = pygame.time.Clock()
        background = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc7739879693323689147A32A39FD692F3CEE69729A5B7E2C6AF1D00970E.jpg'),(SCREENWIDTH,SCREENHEIGHT))
        hint1 = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc181663711075124909999E56E934AB8FEBC20459DCCC35FD8018DA7ECAE.jpg'),(360,200))
        hint2 = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc1816637110751249344A40A00C0EC1F25BF2170C6AB12034E740F4FAB20.jpg'),(360,240))
        hint3 = pygame.transform.scale(pygame.image.load('lib\Images\httpcloud3steamusercontentcomugc1816637110751249344A40A00C0EC1F25BF2170C6AB12034E740F4FAB202.jpg'),(360,460))

        #初始化游戏UI
        MainGame.drawdump = Dump('抽牌堆',SCREENWIDTH-340,460,40)
        MainGame.throwdump = Dump('弃牌堆',SCREENWIDTH-340,680,0)
        MainGame.bossdump = Dump('Boss堆',10,10,12)
        # print(MainGame.drawdump.card_list)
        # print(MainGame.bossdump.card_list)

        #初始化按钮
        MainGame.start_button = StartButton(1050,50,160,40,"开始游戏")
        MainGame.giveup_button = GiveUpButton(350,10,160,40,"放弃游戏")
        MainGame.use_button = UseButton(1025,200,160,40,"出牌")
        MainGame.throw_button = UseButton(1025,200,160,40,"弃牌")
        MainGame.joker_button = JokerButton(1150,140,80,20,"Joker")

        #初始化展示列表
        MainGame.display_list = display_list()

        #初始化音乐
        pygame.mixer.init()
        MainGame.bgm = Music('lib/Music/bgm.mp3')
        MainGame.bgm.play_music()
        MainGame.sound_usecards = Sound('lib/Music/usecards.mp3')
        MainGame.sound_drawcards = Sound('lib/Music/shuffle.wav')

        #刷新窗口
        while True:
            '''
            主程序循环
            '''
            #计时器tick
            MainGame.timer = (MainGame.timer+1)%60
            #背景渲染
            MainGame.window.fill(BLACK)
            MainGame.window.blit(background,(0,0))
            MainGame.window.blit(hint1,(SCREENWIDTH-hint1.get_size()[0],0))
            MainGame.window.blit(hint2,(SCREENWIDTH-hint2.get_size()[0],hint1.get_size()[1]))
            MainGame.window.blit(hint3,(SCREENWIDTH-hint3.get_size()[0],hint1.get_size()[1]+hint2.get_size()[1]))
            #开始游戏后渲染
            if MainGame.is_start:
                if not MainGame.game_over:
                    MainGame.drawdump.display_dump()
                    MainGame.throwdump.display_dump()
                    MainGame.bossdump.display_dump()
                    MainGame.table.display_table()
                    MainGame.joker.display_card()
                    MainGame.giveup_button.display_button()
                    for card in MainGame.cards.values():
                        card.display_card()
                    if MainGame.is_myturn:
                        if MainGame.table.stage == 0:
                            MainGame.use_button.display_button()
                        elif MainGame.table.stage == 1:
                            MainGame.throw_button.display_button()
                        MainGame.joker_button.display_button()
                elif MainGame.game_over:
                    if MainGame.game_lose:
                        #游戏失败
                        MainGame.display_list.display_allowance['游戏失败'] = True
                    if MainGame.game_win:
                        #游戏胜利
                        MainGame.display_list.display_allowance['游戏胜利'] = True
            else:
                MainGame.start_button.display_button()
            
            #展示列表渲染
            MainGame.display_list.display()

            #MainGame.window.blit(self.get_text_surface("弑君者",WHITE,32),(10,10))

            self.get_event()

            pygame.display.update()
            #帧率
            clock.tick(60)

    def get_text_surface(self,text: str,text_color,text_size) -> None:
        '''
        获取文字图片
        '''
        #字体初始化
        pygame.font.init()
        font = pygame.font.SysFont('kaiti',text_size)
        #返回绘制的文字图片
        return font.render(text,True,text_color)

    def get_event(self) -> None:
        '''
        获取事件
        '''
        event_list = pygame.event.get()
        #遍历判断事件
        for event in event_list:
            mx,my = pygame.mouse.get_pos()
            if event.type == pygame.QUIT:
                self.end_game()
            if event.type == pygame.MOUSEBUTTONDOWN:
                MainGame.is_drag = True
                for card in MainGame.cards.values():
                    if is_over_rectangle(mx,my,card.pos[0],card.pos[1],card.width,card.height) and card.is_display:
                        MainGame.select_card = card.name
                        StaticTime.mouse_dpos = [mx-card.pos[0],my-card.pos[1]]
                        break
            if event.type == pygame.MOUSEBUTTONUP:
                MainGame.is_drag = False
                MainGame.select_card = "None"
            if event.type == pygame.MOUSEMOTION:
                if MainGame.is_drag:
                    for card in MainGame.cards.values():
                        if MainGame.select_card != card.name:
                            continue
                        if is_over_rectangle(mx,my,card.pos[0],card.pos[1],card.width,card.height) and card.is_display:
                            print(MainGame.select_card)
                            #print(MainGame.cards[MainGame.select_card])
                            card.move(mx,my)
                        else:
                            MainGame.select_card = "None"
                            card.is_select = False

    def end_game(self) -> None:
        '''
        结束游戏
        '''
        sys.exit()
############################################################################################

def is_over_rectangle(mx,my,x,y,width,height):
    if x<mx and mx<x+width and y<my and my<y+height:
        return True
    return False

class StaticTime():
    start_time = 0
    mouse_dpos = [0,0]
    def __init__(self) -> None:
        pass

def display_for_a_while(surface: pygame.surface,x,y,time):
    current_time = pygame.time.get_ticks()
    if current_time - StaticTime.start_time >= time:
        return False
    MainGame.window.blit(surface,(x,y))
    return True

class display_list():
    display_allowance = {'开始游戏':False,"抽牌":False,"手牌已满":False,'抽牌堆已空':False,'击败了Boss':False,'游戏胜利':False,'游戏失败':False,'出牌非法':False,'Joker已耗尽':False}
    def __init__(self) -> None:
        pass
    def display(self) -> None:
        if self.display_allowance['开始游戏']:
            self.display_allowance['开始游戏'] = display_for_a_while(MainGame.get_text_surface(MainGame,"游戏开始!",WHITE,80),SCREENWIDTH/4+100,350,2000)
        if self.display_allowance['手牌已满']:
            self.display_allowance['手牌已满'] = display_for_a_while(MainGame.get_text_surface(MainGame,"手牌已满!",WHITE,40),SCREENWIDTH/4+175,450,1200)
        if self.display_allowance['抽牌']:
            self.display_allowance['抽牌'] = display_for_a_while(MainGame.drawdump.image,MainGame.table.road_drawdump[0],MainGame.table.road_drawdump[1],2200)
            if not self.display_allowance['抽牌']:
                MainGame.table.update()
        if self.display_allowance['抽牌堆已空']:
            self.display_allowance['抽牌堆已空'] = display_for_a_while(MainGame.get_text_surface(MainGame,"抽牌堆已空!",WHITE,40),SCREENWIDTH/4+175,450,1200)
        if self.display_allowance['击败了Boss'] and not self.display_allowance['游戏胜利']:
            self.display_allowance['击败了Boss'] = display_for_a_while(MainGame.get_text_surface(MainGame,"击败了Boss!",WHITE,80),SCREENWIDTH/4,350,1200)
        if self.display_allowance['游戏胜利']:
            self.display_allowance['游戏胜利'] = display_for_a_while(MainGame.get_text_surface(MainGame,"击败了所有Boss,游戏胜利!",WHITE,80),SCREENWIDTH/4-200,350,5000)
        if self.display_allowance['游戏失败']:
            self.display_allowance['游戏失败'] = display_for_a_while(MainGame.get_text_surface(MainGame,"没有抵挡住Boss攻击,游戏失败!",WHITE,80),SCREENWIDTH/4-350,350,5000)
        if self.display_allowance['出牌非法']:
            self.display_allowance['出牌非法'] = display_for_a_while(MainGame.get_text_surface(MainGame,"非法出牌组合",WHITE,40),SCREENWIDTH/4+100,450,1200)
        if self.display_allowance['Joker已耗尽']:
            self.display_allowance['Joker已耗尽'] = display_for_a_while(MainGame.get_text_surface(MainGame,"非法出牌组合",WHITE,40),SCREENWIDTH/4+50,450,1200)

'''
主程序入口
'''
if __name__ == "__main__":
    MainGame().start_game()